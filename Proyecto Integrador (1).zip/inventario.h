void guardarProductosEnArchivo();
void ingresarProducto();
void modificarProducto();
void eliminarProducto();
void consultarProducto();
void verProductos();