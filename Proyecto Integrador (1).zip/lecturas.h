int leerEntero(const char *mensaje);
int leerEnteroPositivo(const char *mensaje);
float leerFlotante(const char *mensaje);
float leerFlotantePositivo(const char *mensaje);
char leerCaracter(const char *mensaje);
int leerEnteroEntre(const char *mensaje, int minimo, int maximo);
float leerFlotanteEntre(const char *mensaje, float minimo, float maximo);

void leerCadena(char* buffer, int size);