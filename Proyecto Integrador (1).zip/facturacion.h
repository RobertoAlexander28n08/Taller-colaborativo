void ingresarCliente();
void modificarCliente();
void consultarCliente();
void listarClientes();

void facturar();
void buscarFactura();
void listarFacturas();


int obtenerUltimoNumeroFactura();